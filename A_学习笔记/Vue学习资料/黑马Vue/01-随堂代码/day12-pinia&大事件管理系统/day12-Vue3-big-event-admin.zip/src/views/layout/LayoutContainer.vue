<template>
  <div>
    布局架子
    <router-view></router-view>
  </div>
</template>
